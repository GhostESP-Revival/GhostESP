@echo off
"%~dp0TheLongDrive-Roadworthy.exe" --restore-all
